# KarakterVerse

Ensiklopedia karakter anime & donghua (HTML + CSS + JS, tanpa build).

## File
- `index.html` – kerangka halaman
- `style.css` – tema dark (hitam, biru gelap, ungu)
- `app.js` – data awal, pencarian, profil, admin, sinkronisasi AniList

## Deploy ke GitHub Pages
1. Buat repository baru, unggah ketiga file di atas.
2. Settings > Pages > Source: branch `main`, folder `/ (root)`.
3. Buka situsmu, masuk ke menu **Admin**, klik **Sinkronkan semua dari AniList**
   untuk mengambil gambar resmi, tanggal lahir, dan deskripsi.

## Catatan
- Data admin tersimpan di localStorage peramban. Untuk produksi, hubungkan ke backend/database dan tambahkan login.
- Data dari AniList berstatus "wiki komunitas"; periksa kembali sebelum dianggap resmi.
